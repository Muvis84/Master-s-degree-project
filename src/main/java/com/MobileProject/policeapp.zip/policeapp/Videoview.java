package com.example.policeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Videoview extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videoview);
    }
}
